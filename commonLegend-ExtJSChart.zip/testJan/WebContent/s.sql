create or replace PROCEDURE        "RCN_OPENCLOSERECON" IS
  /******************************************************************************
     NAME:       RCN_OPENCLOSERECON
     PURPOSE:

     REVISIONS:
     Ver        Date        Author           Description
     ---------  ----------  ---------------  ------------------------------------
     1.0        2/22/2007          1. Created this procedure.

     NOTES:

     Automatically available Auto Replace Keywords:
        Object Name:     RCN_OPENCLOSERECON
        Sysdate:         2/22/2007
        Date and Time:   2/22/2007, 2:31:59 PM, and 2/22/2007 2:31:59 PM
        Username:         (set in TOAD Options, Procedure Editor)
        Table Name:       (set in the "New PL/SQL Object" dialog)

  ******************************************************************************/
  vemaillist VARCHAR2(4000) := NULL;
  bssemail long;
  hcdate varchar2(100);
  message CLOB := NULL;
  tableFormat CLOB :=NULL;
  reconperiod varchar2(100) := NULL;
BEGIN
  --- open recon--------------
  --RCN_INSERTAUDITMSG(9,'ERECON','Start open recon.');
  BEGIN
    SELECT VALUE
      INTO vemaillist
      FROM app_applicationconfig
     WHERE parameter = 'APP_DISTRIBUTION_LIST';
  EXCEPTION
    WHEN OTHERS THEN
      vemaillist := NULL;
  END;
    -- Modiffied by Parul for email modification
    tableFormat :='<font size= 7" face="calibri"><table border = "1" style = "border-collapse: collapse; margin-left:50px;">
	<tr bgcolor="#D6D7DE">
		<th><b> Recon Period</b></th>
		<th><b> Business Unit</b></th>

		<th><b> Open</b></th>
	</tr>';
  /***********************************START OPEN CYCLE ***************************************************************************/

  FOR rec IN (SELECT reconperiod, businessunit
                FROM rcn_reconsummary
               WHERE reconperiod IN
                     (SELECT DISTINCT reconperiod
                        FROM rcn_cyclecalendar_lu
                       WHERE TRUNC(open_dt) = TRUNC(SYSDATE))
                 AND (OPEN IS NULL OR UPPER(OPEN) != 'O'))

   LOOP
    rcn_insertauditmsg(9,
                       'ERECON',
                       'Begin-1 open recon.' || rec.reconperiod || ', ' ||
                       rec.businessunit,
                       null);
     DELETE FROM rcn_openclosereconsummary
     WHERE businessunit = rec.businessunit
       AND reconperiod = rec.reconperiod;

    COMMIT;
    rcn_openclose(rec.reconperiod, rec.businessunit, 'O', 'S');
    rcn_openclose(rec.reconperiod, rec.businessunit, 'O', 'G');

    UPDATE rcn_reconsummary
       SET settoopen = 1, change_dt = SYSDATE
     WHERE reconperiod = rec.reconperiod
       AND businessunit = rec.businessunit;

     COMMIT;

     -- Modiffied by Parul for email modification
    message := message || '<tr>
                            <td>'||rec.reconperiod||'</td>
                            <td>'||rec.businessunit||'</td>
                            <td>O</td>
                        </tr>';



    IF reconperiod IS NULL THEN
      reconperiod := rec.reconperiod;
    END IF;

   -- IF vemaillist IS NOT NULL THEN
    --  email_insert_email(vemaillist,
                     --    '',
                      --   '',
                       --  'Recon Period: ' || rec.reconperiod ||
                       --  ', Business Unit: ' || rec.businessunit ||
                       --  ', has been opened.');
   -- END IF;

    rcn_insertauditmsg(9,
                       'ERECON',
                       'End-1 open recon.' || rec.reconperiod || ', ' ||
                       rec.businessunit,
                       null);
  END LOOP;
  -- Modiffied by Parul for email modification
  IF message IS NOT NULL THEN
      message:= 'eRecon <b>' || reconperiod ||'</b> Reporting Cycle has entered Open Period.<br><br>' || tableFormat || message || '</font></table>';
      IF vemaillist IS NOT NULL THEN
        email_insert_email(vemaillist,
                             '',
                             '',
                             message,'eRecon Open_Close_Cycle Status | System Has Entered Open Period');
      END IF;
   END IF;
  /***********************************END OPEN CYCLE ***************************************************************************/

  /***********************************START SOFT CLOSE CYCLE ***************************************************************************/
  --RCN_INSERTAUDITMSG(9,'ERECON','Start close recon.');
  message:=NULL;
  reconperiod := NULL;
  FOR rec IN (SELECT reconperiod, businessunit
                FROM rcn_reconsummary
               WHERE reconperiod IN
                     (SELECT DISTINCT reconperiod
                        FROM rcn_cyclecalendar_lu
                       WHERE TRUNC(close_dt) = TRUNC(SYSDATE))
                 AND (OPEN IS NULL OR UPPER(OPEN) != 'A'))

   LOOP
    rcn_insertauditmsg(9,
                       'ERECON',
                       'Begin-1 close recon.' || rec.reconperiod || ', ' ||
                       rec.businessunit,
                       null);

    DELETE FROM rcn_tblfollowuplog
     WHERE businessunit = rec.businessunit
       AND reconperiod = rec.reconperiod;

    COMMIT;

    DELETE FROM rcn_openclosereconsummary
     WHERE businessunit = rec.businessunit
       AND reconperiod = rec.reconperiod;

    COMMIT;
    rcn_openclose(rec.reconperiod, rec.businessunit, 'A', 'S');
    rcn_openclose(rec.reconperiod, rec.businessunit, 'A', 'G');

    UPDATE rcn_reconsummary
       SET settoopen = 1, change_dt = SYSDATE
     WHERE reconperiod = rec.reconperiod
       AND businessunit = rec.businessunit;

    COMMIT;

    -- Modiffied by Parul for email modification
    IF reconperiod IS NULL THEN
      reconperiod := rec.reconperiod;
    END IF;
    message := message || '<tr>
                            <td>'||rec.reconperiod||'</td>
                            <td>'||rec.businessunit||'</td>
                            <td>A</td>
                        </tr>';
    --IF vemaillist IS NOT NULL THEN
     -- email_insert_email(vemaillist,
                       --  '',
                       --  '',
                       --  'Recon Period: ' || rec.reconperiod ||
                       --  ', Business Unit: ' || rec.businessunit ||
                       --  ', has been closed.');
   -- END IF;

    rcn_insertauditmsg(9,
                       'ERECON',
                       'End-1 close recon.' || rec.reconperiod || ', ' ||
                       rec.businessunit,
                       null);
  END LOOP;

  -- Modiffied by Parul for email modification
  IF message IS NOT NULL THEN
      message:= 'eRecon <b>' ||reconperiod ||'</b> Reporting Cycle has entered Adjustment Period.<br><br>' || tableFormat || message || '</font></table>';
      IF vemaillist IS NOT NULL THEN
        email_insert_email(vemaillist,
                             '',
                             '',
                             message,'eRecon Open_Close_Cycle Status | System Has Entered Adjustment Period');
      END IF;
   END IF;

  /***********************************END SOFT CLOSE CYCLE ***************************************************************************/

  /***********************************START HARD CLOSE CYCLE ***************************************************************************/
  message:= NULL;
  reconperiod := NULL;
  FOR rec IN (SELECT reconperiod, businessunit
                FROM rcn_reconsummary
               WHERE reconperiod IN
                     (SELECT DISTINCT reconperiod
                        FROM rcn_cyclecalendar_lu
                       WHERE TRUNC(HARDCLOSE_dt) = TRUNC(SYSDATE))
                 AND (OPEN IS NULL OR UPPER(OPEN) != 'C'))

   LOOP
    rcn_insertauditmsg(9,
                       'ERECON',
                       'Begin-1 open recon.' || rec.reconperiod || ', ' ||
                       rec.businessunit,
                       null);

    DELETE FROM rcn_openclosereconsummary
     WHERE businessunit = rec.businessunit
       AND reconperiod = rec.reconperiod;

    COMMIT;
    rcn_openclose(rec.reconperiod, rec.businessunit, 'C', 'S');
    rcn_openclose(rec.reconperiod, rec.businessunit, 'C', 'G');

    UPDATE rcn_reconsummary
       SET settoopen = 1, change_dt = SYSDATE
     WHERE reconperiod = rec.reconperiod
       AND businessunit = rec.businessunit;

    COMMIT;

    -- Modiffied by Parul for email modification
    IF reconperiod IS NULL THEN
      reconperiod := rec.reconperiod;
    END IF;
   message := message || '<tr>
                            <td>'||rec.reconperiod||'</td>
                            <td>'||rec.businessunit||'</td>
                            <td>C</td>
                        </tr>';
    --IF vemaillist IS NOT NULL THEN
     -- email_insert_email(vemaillist,
                      --   '',
                      --   '',
                       --  'Recon Period: ' || rec.reconperiod ||
                        -- ', Business Unit: ' || rec.businessunit ||
                       --  ', has been opened.');
    --END IF;

    rcn_insertauditmsg(9,
                       'ERECON',
                       'End-1 open recon.' || rec.reconperiod || ', ' ||
                       rec.businessunit,
                       null);
  END LOOP;

  -- Modiffied by Parul for email modification

   IF message IS NOT NULL THEN
      message:= 'eRecon <b>' || reconperiod ||'</b> Reporting Cycle is now closed.<br><br>' || tableFormat || message || '</font></table>';
      IF vemaillist IS NOT NULL THEN
        email_insert_email(vemaillist,
                             '',
                             '',
                             message,'eRecon Open_Close_Cycle Status | System is Now Closed');
      END IF;
   END IF;

  --RCN_INSERTAUDITMSG(9,'ERECON','End close recon.');
  --- end close recon--------------


/* Formatted on 6/30/2015 11:53:52 PM (QP5 v5.163.1008.3004) */
----- BSS BRD 4.9.1------------
----- Chad : 7/1/2015
/* Formatted on 7/1/2015 12:25:11 AM (QP5 v5.163.1008.3004) */
/*SELECT TRUNC (hardclose_dt)
  INTO hcdate
  FROM rcn_cyclecalendar_lu
 WHERE reconperiod = (SELECT VALUE
                        FROM app_applicationconfig
                       WHERE parameter = 'RECONPERIOD');

IF hcdate=TRUNC(SYSDATE) THEN
    FOR i IN (SELECT email FROM rcn_users r,vwuserroles v,mnu_menugrp_lu mn WHERE r.userid=v.userid and v.group_id=mn.group_id
               and r.active_flag='Y'  and v.active_flag='Y'
               and mn.group_desc in ('GOVERNANCE DASHBOARD USER','DASHBOARD VIEWER', 'DASHBOARD USER','GOVERNANCE DASHBOARD VIEWER')
               and r.email is not null
)
        LOOP

        email_insert_email(i.email,'','','The Dashboards are available for your viewing','Dashboards ready');

        END LOOP;
    END IF;


----- BSS BRD 4.9.1------------
 */
EXCEPTION
  WHEN OTHERS THEN
    rcn_insertauditmsg(9,
                       'ERECON',
                       'Error opening RCN_OPENCLOSERECON: ' || SQLERRM,
                       null);
END rcn_opencloserecon;