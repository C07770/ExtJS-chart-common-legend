Ext.define('ERecon.model.Trendmodel', {
	extend : 'Ext.data.Model',
	fields : [ 'reconperiod' ]
});