Ext.define('ERecon.model.Piemodel', {
	extend : 'Ext.data.Model',
	fields : [ 'fkcount', 'description' ]
});