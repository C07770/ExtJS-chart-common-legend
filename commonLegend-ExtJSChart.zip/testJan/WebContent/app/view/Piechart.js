Ext.define('ERecon.view.Piechart', {
	extend : 'Ext.chart.Chart',
	alias : 'widget.piechart',

	store : 'Piestore',
	shadow : true,
	animate : true,
	legend : {
		position : 'left'
	},
	insetPadding : 60,
//	theme : 'CustomTheme',
	
	series : [ {
		type : 'pie',
		field : 'fkcount',
		showInLegend : true,
		donut : false,
		tips : {
			trackMouse : true,
			renderer : function(storeItem, item) {
				var total = 0;
				for (var i = 0; i < item.series.items.length; i++) {
					total += item.series.items[i].slice.value;
				}

				this.update(storeItem.get('description') + ' ('
						+ Math.round(storeItem.get('fkcount') / total * 100)
						+ '%)');
			}
		},
		highlight : {
			segment : {
				margin : 20
			}
		},
		label : {
			field : 'description',
			display : 'rotate',
			contrast : true,
			font : '11px Arial'
		},
		renderers: function(sprite, record, curAttr, index, store) {
			var colorsMap = { 
			  "Mumbai": "#006699",
			  "Heredia": "#339966",
			  "Makati City": "#e6b942",
			  "Buffalo": "#AA0000",
			  "Budapest": "#333366",
			  "Dalian": "#FF6666",
			  "Belfast": "#663333",
			  "Tampa": "#000080",
			  "Mexico City": "#99CCCC",
			  "Shanghai": "#808000",
			  "TCS Chennai": "#008080",
			  "TCS Gurgaon": "#800080",
			  "Regulatory Restricted": "#9999CC",
			  "Other": "#FF99CC" 
			};
			var color = colorsMap[record.data.description];
			console.log(color);
//			Ext.each(m.chart.legend.items, function(legendItem){
//				if(legendItem.label.text === record.data.description) {
//					legendItem.items[1].fill = color;
//					m.chart.legend.redraw();
//				}
//			});

//			sprite.setAttributes({fill: color}, true);
//            return curAttr;
			
			return Ext.apply(curAttr, {
                fill: color
            });
			//return  colorsMap[regions];  
		}
	} ]
});