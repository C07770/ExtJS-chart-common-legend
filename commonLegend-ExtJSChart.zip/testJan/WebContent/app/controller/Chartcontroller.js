Ext.define('ERecon.controller.Chartcontroller', {
	extend : 'Ext.app.Controller',
	requires : [ 'ERecon.store.Trendstore', 'ERecon.model.Trendmodel',
			'ERecon.model.Piemodel', 'ERecon.store.Piestore' ],

	views : [ 'Trendchart', 'Piechart', 'CommonLegend'],

	models : [ 'Piemodel', 'Trendmodel' ],
	stores : [ 'Piestore', 'Trendstore' ],

	refs : [ {
		ref : 'piechart',
		selector : 'piechart',
	}, {
		ref : 'trendchart',
		selector : 'trendchart',
	} , {
		ref : 'commonlegend',
		selector : 'commonlegend',
	} ],

	init : function() {
		this.chartloaded = 0;
		this.control({
			'viewport > container > panel > toolbar > button[action=renderChart]' : {
				click : this.renderChart
			},
			scope : this
		});
	},
	
	renderChart : function() {
		this.renderPieChart();
		this.renderTrendChart();
	},
	
	renderLegends : function() {
		return;
		console.log('render legends from controller called..');
		this.chartloaded = 0;
			this.getPiechart().legend.toggle(true);
			this.getTrendchart().legend.toggle(true);
		var legendCmp = Ext.ComponentQuery.query('[itemId=commonlegend]')[0];
		legendCmp.drawLegend(this.getPiechart(), [this.getTrendchart()]);
	},

	renderPieChart : function() {
		var me = this;
		var pieChart = this.getPiechart();
		
		var pieChartStore = this.getPiestoreStore();
		this.requestData('piedata', function(chartData) {
			chartData = Ext.Array.sort(chartData, function(o1, o2) {
				return o1.description < o2.description ? -1 : (o1.description > o2.description ? 1 : 0);
			});
		
			var chartDataKeys = [];
			for(var i=0; i<chartData.length; i++) {
				chartDataKeys[i] = chartData[i].description;
			}
			
			console.log(pieChart);
			pieChart.theme = me.defineChartTheme("pie", chartDataKeys);

			
			pieChartStore.loadData(chartData);
			pieChart.setLoading(false);
			pieChart.setVisible(true);
			pieChart.redraw();
			me.chartloaded++;
			if(me.chartloaded === 2) 
				me.renderLegends();
		});
	},
	
	renderTrendChart : function() {
		var me = this;
		var trendChart = this.getTrendchart();
		trendChart.series.clear();
		trendChart.surface.removeAll();
		
		this.requestData('trenddata', function(chartData) {
			var trendLines = new Array();
			for (var i = 0; i < chartData.length; i++) {
				var chartDataKeys = Object.keys(chartData[i]).sort();
				for ( var e = 0; e < chartDataKeys.length; e++) {
					var entityName = chartDataKeys[e];
					if (entityName !== 'reconperiod') {
						var line = {
							type : 'line',
							axis : 'left',
							xField : 'reconperiod',
							yField : entityName,
							title : entityName,
							fill : false,
							style : {
								opacity : 1,
								'stroke-width' : 2
							},
							highlight : {
								size : 7,
								radius : 7
							},
							tips: {
								entityName: entityName,
				                trackMouse: true,
				                renderer: function(storeItem, item) {
				                    this.update(this.entityName +' (' + storeItem.get(this.entityName)+ ')');
				                }
				            }
						};

						if (!Ext.Array.contains(trendLines, entityName)) {
							trendChart.series.add(line)
							trendLines.push(entityName);
						}
						
						var modelFields = trendChart.getStore().getProxy().getModel().prototype.fields.keys;
						if(!Ext.Array.contains(modelFields, entityName)) {
							trendChart.getStore().getProxy().getModel().prototype.fields.add(Ext.create('Ext.data.Field', { name: entityName }));
						}
					}
				}
			}
			
			trendChart.getStore().loadData(chartData);
			trendChart.setLoading(false);
			me.chartloaded++;
			if(me.chartloaded === 2) 
				me.renderLegends();
		});
		trendChart.redraw();
	},
	
	defineChartTheme: function(chartType, regions) {
		var colorsMap = { 
			"Mumbai": "#006699",
			"Heredia": "#339966",
			"Makati City": "#e6b942",
			"Buffalo": "#AA0000",
			"Budapest": "#333366",
			"Dalian": "#FF6666",
			"Belfast": "#663333",
			"Tampa": "#000080",
			"Mexico City": "#99CCCC",
			"Shanghai": "#808000",
			"TCS Chennai": "#008080",
			"TCS Gurgaon": "#800080",
			"Regulatory Restricted": "#9999CC",
			"Other": "#FF99CC" 
		};
		
		var colors = [];
		for(var i=0; i<regions.length; i++)
			colors.push(colorsMap[regions[i]]);
		
		var themeName = chartType+"ChartTheme";
		Ext.chart.theme[themeName] = Ext.extend(Ext.chart.theme.Base, {
			constructor : function(config) { 
			    var markerThemes = [], seriesThemes = []; 
			    for (var i=0 ; i < colors.length; i++) { 
			    	var color = colors[i], markerTheme = {}, seriesTheme = {}; 
			
			        markerTheme.type = (i+1)%4 == 0 ? 'diamond' : (i+1)%3 == 0 ? 'cross' : (i+1)%2 == 0 ? 'plus' : 'circle'; 
			        markerTheme.fill = seriesTheme.fill = markerTheme.stroke = seriesTheme.stroke = color; 
			        markerThemes[i] = markerTheme; 
			        seriesThemes[i] = seriesTheme; 
			    } 
			
			    this.callParent([ Ext.apply({ 
			        colors : colors, 
			        markerThemes : markerThemes, 
			        seriesThemes : seriesThemes 
			    }, config) ]); 
			} 
		});
		
		return themeName;
	},
	getSeriesColor : function(regions) { 
		var colorsMap = { 
		  "Mumbai": "#006699",
		  "Heredia": "#339966",
		  "Makati City": "#e6b942",
		  "Buffalo": "#AA0000",
		  "Budapest": "#333366",
		  "Dalian": "#FF6666",
		  "Belfast": "#663333",
		  "Tampa": "#000080",
		  "Mexico City": "#99CCCC",
		  "Shanghai": "#808000",
		  "TCS Chennai": "#008080",
		  "TCS Gurgaon": "#800080",
		  "Regulatory Restricted": "#9999CC",
		  "Other": "#FF99CC" 
		};
		
		return  colorsMap[regions];   
	},
	
	getSeriesColorSet : function(regions) { 
		var colorsMap = { 
		  "Mumbai": "#006699",
		  "Heredia": "#339966",
		  "Makati City": "#e6b942",
		  "Buffalo": "#AA0000",
		  "Budapest": "#333366",
		  "Dalian": "#FF6666",
		  "Belfast": "#663333",
		  "Tampa": "#000080",
		  "Mexico City": "#99CCCC",
		  "Shanghai": "#808000",
		  "TCS Chennai": "#008080",
		  "TCS Gurgaon": "#800080",
		  "Regulatory Restricted": "#9999CC",
		  "Other": "#FF99CC" 
		};
		
		var colorSet = [];
		for(var i=0; i<regions.length; i++)
			colorSet.push(colorsMap[regions[i]]);
		
		return  colorSet;   
	},

	requestData : function(requestedData, callback) {
		var me = this;
		Ext.Ajax.request({
			url : 'http://localhost:8080/sampledata/' + requestedData
					+ '.json',
			success : function(response, opts) {
				var data = Ext.decode(response.responseText);
				callback(data.result, me);
			},
			failure : function(response, opts) {
				console.log('server-side failure with status code '
						+ response.status);
			}
		});
	}
});
