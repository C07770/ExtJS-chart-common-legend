import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.comparator.LastModifiedFileComparator;

public class App {

	public static void main(String[] args) {
		String path = "I://TEST_FOLDER//";
		
		getList(path, 0, 5, false);
		System.out.println(new Date());

	}

	private static List<FileDTO> getList(String path, Integer start, Integer limit, Boolean onlyFolders) {
		try {
			System.out.println(new Date());
			File[] list = new File(path).listFiles(new FileFilter(){
				public boolean accept(File arg) {
					return true;
				}
			});
			List<File> fileList = Arrays.asList(list);
			System.out.println(new Date());
			Collections.sort(fileList, LastModifiedFileComparator.LASTMODIFIED_COMPARATOR);
			System.out.println(new Date());
			/*Collections.sort(fileList, new Comparator<File>(){
				public int compare(File file1, File file2) {
					final long res = file2.lastModified() - file1.lastModified();
					return res < 0 ? -1 : res > 0 ? 1 : 0;
				}
			});*/
			Integer total = 0; 
			if(fileList != null) 
				total = fileList.size();
			
			List<FileDTO> result = new ArrayList<FileDTO>();
			if (fileList != null) {
				for (int i = start; i < fileList.size(); i++) {
					File f = fileList.get(i);
					
					if (!f.exists() || (onlyFolders && !f.isDirectory())) {
						if(f.exists()) total--;
						continue;
					}
					limit--;
					
					FileDTO el = new FileDTO();
					el.setName(f.getName());
					el.setDate(new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss z").format(f.lastModified()));
					el.setSize(FileUtils.byteCountToDisplaySize(f.length()));
					el.setPath(f.getPath());	
					el.setType(f.isFile() ? "file" : "dir");
					result.add(el);
					
					if(limit == 0) break;
				}
			}
			return result;
		} catch (Exception e) {
			return null;
		}
	}

}
